import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service/service.service';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.css']
})
export class PostListComponent implements OnInit {

  post_list:any;

  constructor(private service:ServiceService) { }

  ngOnInit() {
    
    this.service.get_post_list().subscribe(response =>{
      this.post_list = response
    })

    
  }

}
