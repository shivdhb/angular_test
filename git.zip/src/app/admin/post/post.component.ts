import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ServiceService } from '../service/service.service';


@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  constructor(private service : ServiceService) { }

  ngOnInit() {
  }

  signupForm = new FormGroup({
    uname: new FormControl(''),
    email: new FormControl(''),
    number: new FormControl(''),
    profile: new FormControl(''),
    gender: new FormControl(''),
  })

  signupSubmit() {
    let data = this.signupForm.value;
    this.service.update_post_data(data).subscribe((res)=>{
      console.log(res)
    })


    this.signupForm.reset();
  }

}
