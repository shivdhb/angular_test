import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  post_list_url = environment.post_list

  constructor(private http: HttpClient) { }

  // get_post_list_data
  get_post_list() {
    return this.http.get(this.post_list_url)
  }


  // update_profile
  update_post_data(data:any){
    return this.http.post(this.post_list_url,data)
  }


}
