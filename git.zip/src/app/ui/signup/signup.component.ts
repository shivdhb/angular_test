import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  signupForm = new FormGroup({
     uname:new FormControl(''),
     email:new FormControl(''),
     number:new FormControl(''),
     password:new FormControl(''),
     repassword:new FormControl(''),   
    })

signupSubmit(){
 console.log(this.signupForm.value)
 this.signupForm.reset();
}

}
