import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { NofoundComponent } from './ui/nofound/nofound.component';

const routes:Routes = [
  {
    path:'',
    loadChildren:'./ui/ui.module#UiModule',
  },
  {
    path:'dashboard',
    loadChildren:'./admin/admin.module#AdminModule'
  },
  {path:'**',component:NofoundComponent}
]

@NgModule({
  imports: [
    CommonModule,
    [RouterModule.forRoot(routes)],
  ],
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
